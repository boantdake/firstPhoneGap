// Device Event Listener
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){
    console.log('Device is Ready');
}